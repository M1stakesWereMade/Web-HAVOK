<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/Diplom_main.css">

    <?php
    session_start();
    ?>
    <?php require_once("includes/connect.php"); ?>

    <?php
    if(isset($_POST['login'])) {
        if(!empty($_POST['email']) && !empty($_POST['password'])) {
            $email = htmlspecialchars($_POST['email']);
            $password = htmlspecialchars($_POST['password']);
            $query = mysqli_query($con, "SELECT * FROM users WHERE
            email ='".$email."' AND password='".$password."'");
            $numrows = mysqli_num_rows($query);
            if($numrows !=0){
                while($row = mysqli_fetch_assoc($query)) {
                    $dbemail = $row['email'];
                    $dbpassword = $row['password'];
                }
                if ($email == $dbemail && $password == $dbpassword) {
                    $_SESSION['session_email'] = $email; // Сохраняем адрес электронной почты в сессию

                    echo '<meta http-equiv="refresh" content="0;URL=/index.php">';
                }
            } else {
                $message = "Неверное имя пользователя или пароль";
                
            }
        } else {

            if(($_POST['email'])=='' && $_POST['password']!=='') {
            $message = "Логин не должен быть пустым";
            
            }
            if(($_POST['password'])=='' && $_POST['email']!=='') {
                $message = "Пароль не должен быть пустым";
                
            }
            if(($_POST['password'])=='' && $_POST['email']!=='') {
                $message = "Заполните логин и пароль";
                
            }
        }
    }
    ?>

</head>
<body>
    <div class="header_php">
        <a href="index.php">HAVOK</a>
    </div>
    <main class="main_php">
    <div class="main_php_inside">
        <div class="form_boX">
            <form action="" class="autorisation_form" id="loginform" method="post" name="loginform">
                <h1>Вход</h1>
                <?php
                if(!empty($message)) {
                    echo ('<p class = "error">' . '' . $message . '</p>');
                }
                ?>
                <label for="email" class="autorisation_label"><br>
                <input type="text" class="autorisation_input" id="email" name="email" size="32" value="" placeholder="Email аккаунта">
                </label>
                <label for="password" class="autorisation_label"><br>
                <input type="password" class="autorisation_input" id="password" name="password" size="32" value="" placeholder="Пароль">
                </label>
                <input class="button" type="submit" value="Войти" id="login" name="login">
                <a class="href" href="register.php">Регистрация</a>
            </form>
        </div>
    </div>
    </main>
    <footer>
        <div class="container_main_footer">
            <div class="block_info_footer_1">
                <div class="block_info_footer">
                    <span>КОНТАКТЫ</span>
                    <div class="line_footer_inside"></div>
                </div>
                <p><a>+8 985 244 22 98</a></p>
                <p>Ежедневно с 8:00 до 20:00</p>
                <p><a>+8 800 555 55 35</a></p>
                <p>Звонок по России бесплатно </p>
                <p>havokofficial.@mail.ru</p>
            </div>
            <div class="block_pay_footer">
                <div class="block_pay_footer_1">
                    <div class="block_pay_footer">
                        <span>ПРИНИМАЕМ К ОПЛАТЕ</span>
                    <div class="line_footer_inside_1"></div>
                    </div>
                    <img src="/img/paypal-white 1.png">
                    <img src="/img/mastercard 1.png">
                    <img src="/img/visa 1.png">
                </div>
            </div>
        </div>
        <div class="line_main_outside"></div>
</footer>
</body>
</html> 