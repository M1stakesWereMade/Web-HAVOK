<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/Diplom_main.css">

<?php
    session_start();
    ?>
    <?php require_once("includes/connect.php"); ?>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Проверка авторизации пользователя
        if (!isset($_SESSION['session_email'])) {
            $message = 'Войдите в аккаунт чтобы отправить сообщение';
        } else {
            $email = $_POST['email'];
            $reviewText = $_POST['review_text'];

            // Проверка на наличие отзыва
            if (!empty($reviewText)) {
                $query = "INSERT INTO reviews (email, review_text) VALUES ('$email', '$reviewText')";
                $result = mysqli_query($con, $query);

                if ($result) {
                    $message = 'Сообщение отправлено';
                } else {
                    $message = 'Ошибка при отправке сообщения';
                }
            } else {
                $message = 'Поле сообщения не должно быть пустым';
            }
        }
    }
?>
</head>
<body>
    <header>
        <div class="header_img">
            <div class="container_header">
                <div class="text_header">HAVOK</div>
            </div>
        </div>
    </header>
    <main>
        <section class="popular-products">
            <div class="container">
                <a>Популярные товары</a>
                <div class="blocks">
                    <div class="block-product">
                        <img src="/img/Rectangle 32.svg" alt="first-product">
                        <span>НАДУВНЫЕ<br>МАТРАСЫ</span>
                    </div>
                    <div class="block-product">
                        <img src="/img/Rectangle 32(1).svg" alt="second-product">
                        <span>МАЛЫЕ<br>БАССЕЙНЫ</span>
                    </div>
                    <div class="block-product">
                        <img src="/img/Rectangle 32(2).svg" alt="third-product">
                        <span>НАДУВНЫЕ<br>ИГРУШКИ</span>
                    </div>
                    <div class="block-product">
                        <img src="/img/Rectangle 32(3).svg" alt="fourth-product">
                        <span>БОЛЬЛЬШИЕ<br>БАССЕЙНЫ</span>
                    </div>
                </div>
                <div class="blocks">
                    <div class="info-block">
                        <button type="button"><a  href="Contacts.php">узнать больше</a></button>
                    </div>
                </div>
            </div>
        </section>
        <section class="our_task">
            <div class="backgroundimg_our_task">
                <div class="container_task">
                    <div class="our_task_img"></div>
                    <div class="our_task_block">
                        <span>Наша задача - используя наш товар помочь вам насладить водным отдыхом по полной!</span>
                    </div>
                    <div class="boxes">
                        <div class="box">
                            <img src="/img/smileface.svg" alt="proce-boxes-smile-icon">
                            <a>Позитивные эмоции</a>
                        </div>
                        <div class="box">
                            <img src="/img/shar.svg" alt="proce-boxes-smile-icon">
                            <a>По всему<br>миру</a>
                        </div>
                        <div class="box">
                            <img src="/img/shild.svg" alt="proce-boxes-smile-icon">
                            <a>Безопасно</a>
                        </div>
                        <div class="box">
                            <img src="/img/check.svg" alt="proce-boxes-smile-icon">
                            <a>Скидки</a>
                        </div>
                        <div class="big-box">
                            <img src="/img/return.svg" alt="proce-boxes-smile-icon">
                            <a>Круглосуточная cвязь<br>c персоналом </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="task_relax">
            <div class="container_relax">
                <div class="rectangle_relax_img"></div>
                <div class="rectangle_relax_mini"></div>
                <div class="block_relax_info">
                    <div class="container_relax_info">
                        <span class="h1">Отдыхайте с нами</span>
                        <p class="h2">Отдых у моря приподносит много интересного и не менее веселого.</p>
                        <p class="h3">За каждым вашим погружением следует захватывающие открытия.</p>
                        <button type="button"><a  href="#form_section_id">узнать больше</a></button>
                    </div>
                </div>
            </div>
        </section>
        <section class="about_us">
            <div class="container_about_us">
                <div class="about_us_1">
                    <br><span class="about_us_text_1">о нас</span></br>
                    <br><span class="about_us_text_2">Обеспечиваем всеми удобствами для получения удовольствия от отдыха у моря.</span></br>
                    <br><span class="about_us_text_3">Все товары производятся соблюдая все принятые формы безопасности.</span>
                </div>
                <div class="container_about_us_1">
                    <div class="about_us_2">
                        <br><span class="about_us_text_4">“HAVOK” - одна из самых популярных организаций по продаже товаров для водного отдыха по всему миру, компания является грантом безопасности.</span></br>
                    </div>
                    <div class="container_about_us_2">
                        <div class="about_us_3">
                            <br><span class="about_us_text_5">60%</span></br>
                            <br><span class="about_us_text_6">Возвращаются к нам через время, для оформления новых заказов.</span></br>
                        </div>
                        <div class="about_us_4">
                            <br><span class="about_us_text_7">99%</span></br>
                            <br><span class="about_us_text_8">Довольны преобретенными товарами и получеными эмоциями.</span></br>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="form_section" id="form_section_id">
            <div class="container_form_section">
                <div class="form_items">
                    <div class="rectangle_form_mini"></div>
                    <div class="rectangle_form_img"></div>
                    <div class="form_box">
                        <!-- Обратная связь -->
                        <form action="index.php" method="post" name="feedbackform" id="review-form">
                            <h1>Напишите нам</h1>
                            <?php
                            if(!empty($message)) {
                                echo ('<p class = "error">' . '' . $message . '</p>');
                            }
                            ?>
                            <input type="hidden" name="email" value="<?php echo $_SESSION['session_email'];?>">
                            <textarea name="review_text" id="review-text-form" maxlength='500' placeholder="Ваше сообщение..." style="resize: none;"></textarea>
                            <input type="submit" value="Отправить" id="feedback-button">
                            <a class="href" href="register.php">Зарегестрироваться</a>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="container_main_footer">
            <div class="block_info_footer_1">
                <div class="block_info_footer">
                    <span>КОНТАКТЫ</span>
                    <div class="line_footer_inside"></div>
                </div>
                <p><a>+8 985 244 22 98</a></p>
                <p>Ежедневно с 8:00 до 20:00</p>
                <p><a>+8 800 555 55 35</a></p>
                <p>Звонок по России бесплатно </p>
                <p>havokofficial.@mail.ru</p>
            </div>
            <div class="block_pay_footer">
                <div class="block_pay_footer_1">
                    <div class="block_pay_footer">
                        <span>ПРИНИМАЕМ К ОПЛАТЕ</span>
                    <div class="line_footer_inside_1"></div>
                    </div>
                    <img src="/img/paypal-white 1.png">
                    <img src="/img/mastercard 1.png">
                    <img src="/img/visa 1.png">
                </div>
            </div>
        </div>
        <div class="line_main_outside"></div>
    </footer>
</body>
</html> 

