<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/Contacts.css">
</head>
<body>
    <header>
        <div class="header_img">
            <div class="header_container">
                <div class="logo">
                    <a href="index.php">HAVOK</a>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="container_main">
            <h1>КОНТАКТНАЯ ИНФОРМАЦИЯ</h1>
            <div class="container_block">
                <div class="block">
                    <div class="block_inside">
                        <img class="furst_img" src="/img/call-calling.png">
                        <a class="big">Ежедневно с 8:00 до 20:00</a>
                        <a class="normal">Мы принимаем звонки круглосуточно без выходных. Звонок бесплатный.</a>
                        <div class="block_flex">
                            <img class="second_img" src="/img/call-calling.png">
                            <a class="bold">+8 985 244 22 98</a>
                        </div>
                    </div>
                </div>
                <div class="block">
                <div class="block_inside">
                        <img class="furst_img" src="/img/call-calling.png">
                        <a class="big">Звонки по всей России</a>
                        <a class="normal">Мы принимаем звонки круглосуточно без выходных. Звонок бесплатный.</a>
                        <div class="block_flex">
                            <img class="second_img" src="/img/call-calling.png">
                            <a class="bold">+8 800 555 55 35</a>
                        </div>
                    </div>
                </div>
                <div class="block">
                <div class="block_inside">
                        <img class="furst_img" src="/img/sms-tracking.png">
                        <a class="big">Почта для связи</a>
                        <a class="normal">Мы принимаем письма круглосуточно без выходных.</a>
                        <div class="block_flex">
                            <img class="second_img" src="/img/sms-tracking.png">
                            <a class="bold">havokofficial.@mail.ru</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div class="container_main_footer">
            <div class="block_info_footer_1">
                <div class="block_info_footer">
                    <span>КОНТАКТЫ</span>
                    <div class="line_footer_inside"></div>
                </div>
                <p><a>+8 985 244 22 98</a></p>
                <p>Ежедневно с 8:00 до 20:00</p>
                <p><a>+8 800 555 55 35</a></p>
                <p>Звонок по России бесплатно </p>
                <p>havokofficial.@mail.ru</p>
            </div>
            <div class="block_pay_footer">
                <div class="block_pay_footer_1">
                    <div class="block_pay_footer">
                        <span>ПРИНИМАЕМ К ОПЛАТЕ</span>
                    <div class="line_footer_inside_1"></div>
                    </div>
                    <img src="/img/paypal-white 1.png">
                    <img src="/img/mastercard 1.png">
                    <img src="/img/visa 1.png">
                </div>
            </div>
        </div>
        <div class="line_main_outside"></div>
    </footer>
</body>
</html>