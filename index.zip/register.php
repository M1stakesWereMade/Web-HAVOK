<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/Diplom_main.css">

    <?php
    session_start();
    ?>
    <?php require_once("includes/connect.php"); ?>

    <?php
    if(isset($_POST["register"])) {
        if(!empty($_POST['username']) &&
        !empty($_POST['email']) && !empty($_POST['password'])) {
            $username = htmlspecialchars($_POST['username']);
            $email = htmlspecialchars($_POST['email']);
            $password = htmlspecialchars($_POST['password']);

            $query = mysqli_query($con, "SELECT * FROM users WHERE
            email ='".$email."'");
            $numrows = mysqli_num_rows($query);
            if($numrows == 0) {
                $sql = "INSERT INTO users (username, email, password) 
                VALUES ('$username','$email','$password')";
                $result = mysqli_query($con, $sql);
                if($result) {
                    $message = 'Аккаунт успешно создан';
                } else {
                    $message = 'Невозможно добавить в БД';
                }
            } else {
                $message = 'Введённая почта уже есть в БД Нужно другое';
        }
    } else {
        $message = 'Все поля небходимо заполнить';
        }
    }
    ?>

</head>
<body>
    <div class="header_php">
        <a href="index.php">HAVOK</a>
    </div>
    <main class= "main_php">
        <div class="main_php_inside">
            <div class="form_boX">
                <form action="register.php" class="autorisation_form" id="registerform" method="post" name="registerform">
                    <h1>Регистрация</h1>
                    <?php
                    if(!empty($message)) {
                        echo ('<p class = "error">' . '' . $message . '</p>');
                    }
                    ?>
                    <label for="username" class="autorisation_label"><br>
                        <input type="text" class="autorisation_input"  id="username" name="username" size="32" value="" placeholder="Имя аккаунта" required> 
                    </label>
                    <label for="email" class="autorisation_label"><br>
                        <input type="email" class="autorisation_input" id="email" name="email" size="32" value="" placeholder="Email" required>
                    </label>
                    <label for="password" class="autorisation_label"><br>
                        <input type="password" class="autorisation_input" id="password" name="password" size="32" value="" placeholder="Пароль" required>
                    </label>
                    <input class="button_reg" type="submit" value="Зарегестрироваться" id="register" name="register">
                    <a class="href" href="login.php">Войти</a>
                </form>
            </div>
        </div>
    </main>
    <footer>
        <div class="container_main_footer">
            <div class="block_info_footer_1">
                <div class="block_info_footer">
                    <span>КОНТАКТЫ</span>
                    <div class="line_footer_inside"></div>
                </div>
                <p><a>+8 985 244 22 98</a></p>
                <p>Ежедневно с 8:00 до 20:00</p>
                <p><a>+8 800 555 55 35</a></p>
                <p>Звонок по России бесплатно </p>
                <p>havokofficial.@mail.ru</p>
            </div>
            <div class="block_pay_footer">
                <div class="block_pay_footer_1">
                    <div class="block_pay_footer">
                        <span>ПРИНИМАЕМ К ОПЛАТЕ</span>
                    <div class="line_footer_inside_1"></div>
                    </div>
                    <img src="/img/paypal-white 1.png">
                    <img src="/img/mastercard 1.png">
                    <img src="/img/visa 1.png">
                </div>
            </div>
        </div>
        <div class="line_main_outside"></div>
    </footer>
</body>
</html> 